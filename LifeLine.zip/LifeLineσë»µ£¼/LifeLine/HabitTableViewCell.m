//
//  HabitTableViewCell.m
//  LifeLine
//
//  Created by Charvel on 16/5/17.
//  Copyright © 2016年 Jarvis. All rights reserved.
//

#import "HabitTableViewCell.h"

@implementation HabitTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)addHabit:(id)sender {
}
- (IBAction)doHabit:(id)sender {
}
@end
